package com.technical_test.testcases;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.technical_test.pageobjects.HomePage;
import com.technical_test.pageobjects.PayBillingPage;

public class TcPayBilling {
	
	WebDriver driver;
	String id;
		public TcPayBilling (WebDriver driver){
	       this.driver=driver;

	       PageFactory.initElements(driver, this);
	   }
	   
	   public void payBilling(String customerID) {
	       
	       HomePage home = new HomePage(driver);
	       home.clickOnPayBilling();

	       PayBillingPage paybilling = new PayBillingPage(driver);
	     
	       Assert.assertTrue(paybilling.isPageOpened());
	       
	       paybilling.setCustomerID(customerID);

	       paybilling.clickSubmit();
	       
	       WebDriverWait wait = new WebDriverWait(driver, 5);
	       
	       if(paybilling.isPage2Opened()){
	    	   
			   System.out.println("Pay Billing");
			   
	       }else{
	    	   
	    	   System.out.println("Failed: Please Input Your Correct Customer ID");
	       }
	       
	       }

}
