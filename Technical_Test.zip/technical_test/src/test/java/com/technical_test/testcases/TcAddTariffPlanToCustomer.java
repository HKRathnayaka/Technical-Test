package com.technical_test.testcases;

import com.technical_test.pageobjects.HomePage;
import com.technical_test.pageobjects.AddTariffPlanToCustomerPage;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TcAddTariffPlanToCustomer {
	
	WebDriver driver;
	
		public TcAddTariffPlanToCustomer (WebDriver driver){
	       this.driver=driver;

	       PageFactory.initElements(driver, this);
	   }
	   
	   public void addTariffPlanToCustomer(String customerID) throws InterruptedException {
	       
	       HomePage home = new HomePage(driver);
	       home.clickOnAddTariffPlanToCustomer();

	       AddTariffPlanToCustomerPage add = new AddTariffPlanToCustomerPage(driver);
	     
	       Assert.assertTrue(add.isPageOpened());
	       
	       add.setCustomerID(customerID);

	       add.clickSubmit();
	       
	       WebDriverWait wait = new WebDriverWait(driver, 5);
	       
	       if(add.isPage2Opened()){
	    	   
	    	   add.radioButtonCheck();
	    	   add.clickSubmit();
	    	   wait.wait();
	    	   Assert.assertTrue(add.isPage3Opened());
			   System.out.println("Tariff Plan assigned");
			   
	       }else{
	    	   
	    	   Assert.assertTrue(add.isPage2Opened());
	    	   System.out.println("Failed: Please Input Your Correct Customer ID");
	       }
	       
	       }

}
