package com.technical_test.testcases;

import com.technical_test.pageobjects.AddCustomerPage;
import com.technical_test.pageobjects.HomePage;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TcAddCustomer {

	WebDriver driver;
	String id;
		public TcAddCustomer (WebDriver driver){
	       this.driver=driver;

	       PageFactory.initElements(driver, this);
	   }
	   
	   public String addCustomer(String backgroundcheck, String firstname, String lastname, String email, String address, String mobilenumber) {
	       
	       HomePage home = new HomePage(driver);
	       home.clickOnAddCustomer();

	       AddCustomerPage add = new AddCustomerPage(driver);
	     
	       Assert.assertTrue(add.isPageOpened());
	       
	       add.backgroundCheck(backgroundcheck);
	       add.setFirstName(firstname);
	       add.setLastName(lastname);
	       add.setEmail(email);
	       add.setAddress(address);
	       add.setMobileNumber(mobilenumber);

	       add.clickSubmit();
	       
	       WebDriverWait wait = new WebDriverWait(driver, 5);
	       
	       if(isAlertPresents()){
	    	   
	    	   Alert alert = driver.switchTo().alert();
			   String alertMessage= driver.switchTo().alert().getText();
			   System.out.println("Failed to add customer "+alertMessage);
			   alert.accept();
			   driver.quit();
			   
	       }else{
	    	   
	    	   Assert.assertTrue(add.isPage2Opened());
	    	   System.out.println("Customer Added. ID: "+add.customerID());
	    	   id = add.customerID();
	       }
	       return id;
	       
	       
	   }
	   
	    
	    private boolean isAlertPresents() {
	    	try {
	    			driver.switchTo().alert();
	    			return true;
	    		}
	    		catch (Exception e) {
	    			return false;
	    		}
	    }
		public void close(){
	    	driver.close();
	       }
	
}
