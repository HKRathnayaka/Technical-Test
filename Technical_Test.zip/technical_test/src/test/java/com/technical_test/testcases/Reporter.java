package com.technical_test.testcases;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Reporter {
	
	 public WebDriver driver;
	 public ExtentHtmlReporter htmlReporter;
	 public ExtentReports extent;
	 public ExtentTest test;
	 public static String customerID;

	 @BeforeTest
	 public void setExtent() {

	  htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/TestReport.html");

	  htmlReporter.config().setDocumentTitle("Automation Report");
	  htmlReporter.config().setReportName("Functional Testing");
	  htmlReporter.config().setTheme(Theme.DARK);
	  
	  extent = new ExtentReports();
	  extent.attachReporter(htmlReporter);
	  
	  extent.setSystemInfo("Host name", "localhost");
	  extent.setSystemInfo("Environemnt", "QA");
	  extent.setSystemInfo("user", "hashan");
	 }

	 @AfterTest
	 public void endReport() {
	  extent.flush();
	 }

	 @BeforeMethod
	 public void setup() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Hashan Kanishka\\Desktop\\Test\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 
	 }

	 @Test
	 public void addCustomer() {
		  test = extent.createTest("Add Customer");
		  TcAddCustomer add = new TcAddCustomer(driver);
		  add.addCustomer("done", "John", "Doe", "john.doe@gmail.com", "Address", "002684598459");
		  customerID = add.id;
		 }
	 
	 @Test
	 public void addTariffplane() {
		  test = extent.createTest("Add Tariff Plans");
		  TcAddTariffplane add = new TcAddTariffplane(driver);
		  add.addTariffplane(4, 2, 5, 3, 2, 3, 1);
		  
		 }
	 
	 @Test
	 public void addTariffPlanToCustomer() throws InterruptedException {
		  test = extent.createTest("Add Tariff Plan to Customer");
		  TcAddTariffPlanToCustomer add = new TcAddTariffPlanToCustomer(driver);
		  add.addTariffPlanToCustomer(customerID);
		  
		 }
	 
	 @Test
	 public void payBilling() {
		  test = extent.createTest("Pay Billing");
		  TcPayBilling add = new TcPayBilling(driver);
		  add.payBilling(customerID);
		  
		 }
  
	 @AfterMethod
	 public void tearDown(ITestResult result) throws IOException {
	  if (result.getStatus() == ITestResult.FAILURE) {
	   test.log(Status.FAIL, "TEST CASE FAILED IS " + result.getName());
	   test.log(Status.FAIL, "TEST CASE FAILED IS " + result.getThrowable());
	   String screenshotPath = Reporter.getScreenshot(driver, result.getName());
	   test.addScreenCaptureFromPath(screenshotPath);
	  } else if (result.getStatus() == ITestResult.SKIP) {
	   test.log(Status.SKIP, result.getName() + " Test Case SKIPPED");
	  }
	  else if (result.getStatus() == ITestResult.SUCCESS) {
	   test.log(Status.PASS, result.getName() + " Test Case PASSED");
	  }
	  driver.quit();
	 }
	 
	 public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException {
	  String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
	  TakesScreenshot ts = (TakesScreenshot) driver;
	  File source = ts.getScreenshotAs(OutputType.FILE);
	  
	  String destination = System.getProperty("user.dir") + "/Screenshots/" + screenshotName + dateName + ".jpg";
	  File finalDestination = new File(destination);
	  FileUtils.copyFile(source, finalDestination);
	  return destination;
	 }

}
