package com.technical_test.testcases;

import com.technical_test.pageobjects.AddTariffPlansPage;
import com.technical_test.pageobjects.HomePage;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TcAddTariffplane {

	WebDriver driver;
	
		public TcAddTariffplane (WebDriver driver){
	       this.driver=driver;

	       PageFactory.initElements(driver, this);
	   }
	   
	   public void addTariffplane(int monthlyrental, int freelocalminutes, int freeinternationalminutes, int reesmspack, int localperminutescharges, int internationalperminutescharges, int smspercharges) {
	       
	       HomePage home = new HomePage(driver);
	       home.clickOnAddTariffPlan();

	       AddTariffPlansPage addTP = new AddTariffPlansPage(driver);
	     
	       Assert.assertTrue(addTP.isPageOpened());
	       
	       addTP.setMonthlyRental(monthlyrental);
	       addTP.setFreeLocalMinutes(freelocalminutes);
	       addTP.setFreeInternationalMinutes(freeinternationalminutes);
	       addTP.setFreeSMSPack(reesmspack);
	       addTP.setLocalPerMinutesCharges(localperminutescharges);
	       addTP.setInternationalPerMinutesCharges(internationalperminutescharges);
	       addTP.setSMSPerCharges(smspercharges);

	       addTP.clickSubmit();
	       
	       WebDriverWait wait = new WebDriverWait(driver, 5);
	       
	       if(isAlertPresents()){
	    	   
	    	   Alert alert = driver.switchTo().alert();
			   String alertMessage= driver.switchTo().alert().getText();
			   System.out.println("Failed to add Tariff Plan "+alertMessage);
			   alert.accept();
			   driver.quit();
			   
	       }else{
	    	   
	    	   Assert.assertTrue(addTP.isPageOpened());
	    	   
	    	   System.out.println("Congratulation you add Tariff Plan");
	    	   
	       }
	   }
	   
	    
	    private boolean isAlertPresents() {
	    	try {
	    			driver.switchTo().alert();
	    			return true;
	    		}
	    		catch (Exception e) {
	    			return false;
	    		}
	    }
		public void close(){
	    	driver.close();
	       }
}
