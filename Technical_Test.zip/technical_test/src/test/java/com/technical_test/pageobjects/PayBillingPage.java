package com.technical_test.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PayBillingPage {
	@FindBy(xpath = "//div/header/h1")
	   WebElement lable;
	   
	   public boolean isPageOpened(){
	       return lable.getText().toString().contains("Pay Billing");
	   }

	   @FindBy(id="customer_id")
	   WebElement customerID;
	   
	   @FindBy(xpath = "//form/div/div[6]/input")
	   WebElement submitButton;

	   public PayBillingPage (WebDriver driver){
	       PageFactory.initElements(driver, this);
	   }
	   
	   public void setCustomerID(String CustomerID){
		   
		   customerID.sendKeys(CustomerID);
	   }
	   
	   public void clickSubmit(){
		   submitButton.click();
	   }
	   
	   @FindBy(xpath = "//div/header/h1")
	   WebElement lable2;
	   
	   public boolean isPage2Opened(){
	       return lable2.getText().toString().contains("Pay Billing");
	   }
}
