package com.technical_test.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
		private static String PAGE_URL="http://demo.guru99.com/telecom/";

	   @FindBy(how = How.LINK_TEXT, using = "Add Customer")
	   private WebElement addCustomerLink;
	   
	   @FindBy(how = How.LINK_TEXT, using = "Add Tariff Plan")
	   private WebElement addTariffPlanLink;
	   
	   @FindBy(how = How.LINK_TEXT, using = "Add Tariff Plan to Customer")
	   private WebElement addTariffPlanToCustomerLink;
	   
	   @FindBy(how = How.LINK_TEXT, using = "Pay Billing")
	   private WebElement payBillingLink;

	   public HomePage(WebDriver driver){
	       driver.get(PAGE_URL);
	       PageFactory.initElements(driver, this);
	   }
	   
	   public void clickOnAddCustomer(){

		   addCustomerLink.click();

	   }
	   
	   public void clickOnAddTariffPlan(){

		   addTariffPlanLink.click();

	   }
	   
	   public void clickOnAddTariffPlanToCustomer(){

		   addTariffPlanToCustomerLink.click();

	   }
	   
	   public void clickOnPayBilling(){

		   payBillingLink.click();

	   }
	   
}
