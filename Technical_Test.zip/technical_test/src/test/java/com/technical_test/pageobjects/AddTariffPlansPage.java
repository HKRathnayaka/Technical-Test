package com.technical_test.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddTariffPlansPage {
	
	@FindBy(xpath = "//div/header/h1")
	   WebElement lable;
	   
	   public boolean isPageOpened(){
	       return lable.getText().toString().contains("Add Tariff Plans");
	   }

	   @FindBy(id="rental1")
	   WebElement monthlyRental;
	   
	   @FindBy(id="local_minutes")
	   WebElement freeLocalMinutes;
	   
	   @FindBy(id="inter_minutes")
	   WebElement freeInternationalMinutes;
	   
	   @FindBy(id="sms_pack")
	   WebElement freeSMSPack;
	   
	   @FindBy(id="minutes_charges")
	   WebElement localPerMinutesCharges;
	   
	   @FindBy(id="inter_charges")
	   WebElement internationalPerMinutesCharges;
	   
	   @FindBy(id="sms_charges")
	   WebElement smsPerCharges;
	   
	   @FindBy(xpath = "//form/div/div[36]/ul/li[1]/input")
	   WebElement submitButton;
	   
	   @FindBy(xpath = "//div/h2")
	   WebElement lable2;

	   public AddTariffPlansPage (WebDriver driver){
	       PageFactory.initElements(driver, this);
	   }
	   
	   public void setMonthlyRental(int MonthlyRental){
		   
		   monthlyRental.sendKeys(""+MonthlyRental);
	   }
	   
	   public void setFreeLocalMinutes(int FreeLocalMinutes){
	      
		   freeLocalMinutes.sendKeys(""+FreeLocalMinutes);
	   }

	   public void setFreeInternationalMinutes(int FreeInternationalMinutes){
	       
		   freeInternationalMinutes.sendKeys(""+FreeInternationalMinutes);
	   }

	   public void  setFreeSMSPack(int FreeSMSPack){
		
		   freeSMSPack.sendKeys(""+FreeSMSPack);
	   }

	   public void setLocalPerMinutesCharges (int LocalPerMinutesCharges){
	       
		   localPerMinutesCharges.sendKeys(""+LocalPerMinutesCharges);
	   }
	   
	   public void setInternationalPerMinutesCharges (int InternationalPerMinutesCharges){
	       
		   internationalPerMinutesCharges.sendKeys(""+InternationalPerMinutesCharges);
	   }
	   

	   public void setSMSPerCharges (int SMSPerCharges){
	       
		   smsPerCharges.sendKeys(""+SMSPerCharges);
	   }
	   
	   public void clickSubmit(){
		   submitButton.click();
	   }
	   
	   public boolean isPage2Opened(){
	       return lable2.getText().toString().contains("Congratulation you add Tariff Plan");
	   }
}
