package com.technical_test.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AddCustomerPage {
		
	private WebDriver driver;

	   @FindBy(xpath = "//div/header/h1")
	   WebElement lable;
	   
	   public boolean isPageOpened(){
	       return lable.getText().toString().contains("Add Customer");
	   }

	   @FindBy(xpath = "//form/div/div[1]/label")
	   WebElement doneButton;
	   
	   @FindBy(xpath = "//form/div/div[2]/label")
	   WebElement pendingButton;
	   
	   @FindBy(id="fname")
	   WebElement firstName;
	   
	   @FindBy(id="lname")
	   WebElement lastName;
	   
	   @FindBy(id="email")
	   WebElement email;
	   
	   @FindBy(name="addr")
	   WebElement address;
	   
	   @FindBy(id="telephoneno")
	   WebElement mobileNumber;
	   
	   @FindBy(xpath = "//form/div/div[9]/ul/li[1]/input")
	   WebElement submitButton;
	   
	   @FindBy(xpath = "//div/header/h1")
	   WebElement lable2;
	   
	   @FindBy(xpath = "//div/div/table/tbody/tr[1]/td[2]/h3")
	   WebElement customerID;

	   public AddCustomerPage (WebDriver driver){
	       this.driver=driver;

	       PageFactory.initElements(driver, this);
	   }
	   
	   public void backgroundCheck(String backgroundCheck){
		   
		   if(backgroundCheck.equalsIgnoreCase("Done")){
			   doneButton.click();
		   }else{
			   pendingButton.click();
		   }   
	   }
	   
	   public void setFirstName(String FirstName){
	      
		   firstName.sendKeys(FirstName);
	   }

	   public void setLastName(String LastName){
	       
		   lastName.sendKeys(LastName);
	   }

	   public void  setEmail(String Email){
		
	       email.sendKeys(Email);
	   }

	   public void setAddress (String Address){
		   
		   WebDriverWait wait = new WebDriverWait(driver, 10);
		   address.sendKeys(Address);
	   }
	   
	   public void setMobileNumber (String MobileNumber){
	       
		   mobileNumber.sendKeys(MobileNumber);
	   }
	   
	   public void clickSubmit(){
		   submitButton.click();
	   }
	   
	   public boolean isPage2Opened(){
	       return lable2.getText().toString().contains("Access Details to Guru99 Telecom");
	   }
	   
	   public String customerID(){
	       return customerID.getText().toString();
	   }
	
	   
}
