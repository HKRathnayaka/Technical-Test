package com.technical_test.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddTariffPlanToCustomerPage {
	
	@FindBy(xpath = "//div/header/h1")
	   WebElement lable;
	   
	   public boolean isPageOpened(){
	       return lable.getText().toString().contains("Add Tariff Plan to Customer");
	   }

	   @FindBy(id="customer_id")
	   WebElement customerID;
	   
	   @FindBy(xpath = "//form/div/div[6]/input")
	   WebElement submitButton;
	   
	   

	   public AddTariffPlanToCustomerPage (WebDriver driver){
	       PageFactory.initElements(driver, this);
	   }
	   
	   public void setCustomerID(String CustomerID){
		   
		   customerID.sendKeys(CustomerID);
	   }
	   
	   public void clickSubmit(){
		   submitButton.click();
	   }
	   
	   @FindBy(xpath = "//div/header/h1")
	   WebElement lable2;
	   
	   public boolean isPage2Opened(){
	       return lable2.getText().toString().contains("Add Tariff Plan to Customer");
	   }
	   
	   @FindBy(xpath = "//form/div[1]/table/tbody/tr/td[1]/label")
	   WebElement radioButton;
	   
	   @FindBy(xpath = "//form/div[2]/input")
	   WebElement addPlan;
	   
	   public void radioButtonCheck(){
		   
		   radioButton.click();
	     
	   }
   		public void clickSubmit2(){
   		
   			addPlan.click();
   		
	   }
   		
   		@FindBy(xpath = "//div/h2")
		 WebElement lable3;
	   	
   		public boolean isPage3Opened(){
 	       return lable3.getText().toString().contains("Congratulation Tariff Plan assigned");
 	   }

}
